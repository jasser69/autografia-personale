# Jasser Haj Hassiene - Portfolio Personale

Questo è il portfolio personale di Jasser Haj Hassiene, studente di odontotecnica e creativo digitale. Il sito è stato realizzato con le seguenti tecnologie:

- **Astro 5**: Framework per la creazione di siti web statici ultra-performanti.
- **Tailwind CSS v4**: Framework CSS utility-first per un design rapido e personalizzabile.
- **GSAP**: Libreria per animazioni JavaScript di alta qualità.
- **Three.js**: Libreria JavaScript per la creazione di grafica 3D nel browser.
- **Decap CMS**: Content Management System basato su Git per la gestione dei contenuti.

## Caratteristiche Principali

- Design moderno e pulito, ispirato allo stile Apple.
- Animazioni fluide e interattive.
- Modello 3D di un dente stilizzato nella sezione Hero.
- Supporto completo per la Dark Mode.
- Pannello di amministrazione (`/admin`) per la gestione di progetti, articoli del blog e testimonianze.
- Completamente responsive per desktop, tablet e mobile.

## Installazione e Avvio

Per avviare il progetto in locale:

1. Clona il repository:
   ```bash
   git clone https://github.com/TUO_USERNAME/jasser-portfolio.git
   cd jasser-portfolio
   ```
2. Installa le dipendenze:
   ```bash
   npm install
   ```
3. Avvia il server di sviluppo:
   ```bash
   npm run dev
   ```

Il sito sarà disponibile all'indirizzo `http://localhost:3000`.

## Gestione Contenuti

Per accedere al pannello di amministrazione di Decap CMS, visita `http://localhost:3000/admin` (o `/admin` sul tuo sito deployato). Avrai bisogno di configurare l'autenticazione GitHub per il CMS.

## Deployment

Per istruzioni dettagliate sul deployment del sito su piattaforme come Netlify o Vercel, consulta il file `DEPLOYMENT_GUIDE.md` presente nella root del progetto.

---

**Creato con ❤️ da Jasser Haj Hassiene**
