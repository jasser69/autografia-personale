import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

/**
 * 3D Tooth Model Component
 * Creates a stylized cartoon tooth with floating and mouse-following animations
 */
export default function ToothModel() {
  const containerRef = useRef(null);
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const rendererRef = useRef(null);
  const toothRef = useRef(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const targetRotationRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 3;
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Create tooth geometry
    const toothGeometry = new THREE.BufferGeometry();

    // Tooth vertices (simplified cartoon tooth)
    const vertices = new Float32Array([
      // Crown (top part)
      0, 1, 0,      // tip (0)
      -0.4, 0.8, 0, // left top (1)
      0.4, 0.8, 0,  // right top (2)
      -0.5, 0.3, 0, // left middle (3)
      0.5, 0.3, 0,  // right middle (4)
      -0.4, -0.2, 0, // left bottom (5)
      0.4, -0.2, 0,  // right bottom (6)
      
      // Root (bottom part)
      -0.3, -0.5, 0, // left root top (7)
      0.3, -0.5, 0,  // right root top (8)
      -0.2, -1, 0,   // left root bottom (9)
      0.2, -1, 0,    // right root bottom (10)
      0, -1.2, 0,    // root tip (11)
    ]);

    const indices = [
      // Crown faces
      0, 1, 2,
      1, 3, 2,
      2, 3, 4,
      3, 5, 4,
      4, 5, 6,
      
      // Root faces
      5, 7, 6,
      6, 7, 8,
      7, 9, 8,
      8, 9, 10,
      9, 11, 10,
    ];

    toothGeometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
    toothGeometry.setIndex(new THREE.BufferAttribute(new Uint16Array(indices), 1));
    toothGeometry.computeVertexNormals();

    // Material - pearlescent white
    const toothMaterial = new THREE.MeshPhongMaterial({
      color: 0xf5f5f7,
      emissive: 0xffffff,
      emissiveIntensity: 0.2,
      shininess: 100,
      wireframe: false,
    });

    const tooth = new THREE.Mesh(toothGeometry, toothMaterial);
    toothRef.current = tooth;
    scene.add(tooth);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(5, 5, 5);
    scene.add(directionalLight);

    const pointLight = new THREE.PointLight(0x0071e3, 0.5);
    pointLight.position.set(-5, 3, 5);
    scene.add(pointLight);

    // Mouse tracking
    const onMouseMove = (event) => {
      mouseRef.current.x = (event.clientX / window.innerWidth) * 2 - 1;
      mouseRef.current.y = -(event.clientY / window.innerHeight) * 2 + 1;
    };

    window.addEventListener('mousemove', onMouseMove);

    // Animation variables
    let floatOffset = 0;
    const floatSpeed = 0.01;
    const floatAmplitude = 0.2;

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);

      if (toothRef.current) {
        // Floating animation
        floatOffset += floatSpeed;
        toothRef.current.position.y = Math.sin(floatOffset) * floatAmplitude;

        // Mouse follower with easing
        targetRotationRef.current.x += (mouseRef.current.y - targetRotationRef.current.x) * 0.05;
        targetRotationRef.current.y += (mouseRef.current.x - targetRotationRef.current.y) * 0.05;

        toothRef.current.rotation.x = targetRotationRef.current.x * 0.5;
        toothRef.current.rotation.y = targetRotationRef.current.y * 0.5;
      }

      renderer.render(scene, camera);
    };

    animate();

    // Handle window resize
    const onWindowResize = () => {
      if (!containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;

      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', onWindowResize);

    // Cleanup
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('resize', onWindowResize);
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
      toothGeometry.dispose();
      toothMaterial.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="w-full h-full min-h-96"
      style={{
        background: 'radial-gradient(circle at center, rgba(0, 113, 227, 0.1) 0%, transparent 70%)',
      }}
    />
  );
}
